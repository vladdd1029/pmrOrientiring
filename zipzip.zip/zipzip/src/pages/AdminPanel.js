import React from 'react'

export default function AdminPanel() {
  return (
    <div>
      adminnn
    </div>
  )
}
