import React from 'react'


export default function Main() {
    return (
        <div>
            Добро пожаловать на главную страницу!
        </div>
    )
}
